import { Component } from "react";


export default function Sprite(){
  return (
    <div
      style={{
        display:"inline-block",
        height:32,
        width:32,
        backgroundImage:"url('./component/amg1_bk1.png')",
        backgroundRepeat:"no-repeat",
      }}>

    </div>
  )
}