import logo from './logo.svg';
import './App.css';
import Sprite from './component/sprite/index'

function App() {
  return (
    <div className="zone-container" >
        <Sprite/>
    </div>
  );
}

export default App;
